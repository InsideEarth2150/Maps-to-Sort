Map Name - "(4) Timber"
Players - 4
Size - Large
Tileset - Summer
Tunnel Layer - no
Water - Yes
Difficult terrian - medium
Resources - much
water - little
Need for expansion - much

Made by Faceless Clock

---------------------

----------------------
Notes:
This map is a forest map. It is mostly grass and trees, with some desert far up north. 
Players start in the cornors. There are lot of resources spread out across the map. In the
center of the map is a ruined town.
----------------------
Installation
To install the map, put the .Ind and .mis files in the C:\programfiles\SSI\earth2150\levels
directory. You may have to create a levels directory in the earth2150 folder. I'm not sure,
i didn't check it out before i made the map.
----------------------
Feedback
If you have comments or questions about the map, e-mail me at cmsmith@one.net