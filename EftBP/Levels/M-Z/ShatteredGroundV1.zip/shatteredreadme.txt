Map Name - "(6) Shattered Ground"
Author - Faceless Clock
E-mail - Cmsmith@one.net
Tileset - Summer
Subtype - Mountains
Size - Large
Players - 6
Unzipped - 70kb
Zipped - 68.5kb
Tunnel Layer - yes
Water - yes, but does not effect gameplay
Difficult terrian - much
Resources - much
water - little
Need for expansion - much

Made by Faceless Clock

---------------------

----------------------
Description:
Players start on one of 6 high areas. There are plenty of of areas to expand too, and expanding
will give you a big advantage. The Terrian is rocky, so planes can be very useful. The water 
is outside the map's border, so ships are not buildable. 
----------------------
Installation
To install the map, put the .Ind and .mis files in the C:\programfiles\SSI\earth2150\levels
directory. You may have to create a levels directory in the earth2150 folder. 
----------------------
Feedback
If you have comments or questions about the map, e-mail me at cmsmith@one.net