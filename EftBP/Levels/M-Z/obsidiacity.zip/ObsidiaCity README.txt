                  ObsidiaCity
_________________________________________________

This is a 4 platform map for 1v1 or 2v2.  Players
1 & 2 start off on the South side, and 3 & 4 start
off to the North.  Resources are plentiful on the
starting platform, but these are it.  Critical
balance of building up resources and preparing for
battle.  Scouting is essential, and basic terrain
leaves very little hiding spots.  Tunnel System
in the middle is just straight tunnel dividing
East and West.  It leaves very little for quick
attacks underground.   Platformed middle leaves
air assaults open for counterattack if used well.
This is an Air Map, and some Anti Air is assumed.
Since it is Lunar Terrain, somewhat bland looking,
& very rocky.   Have fun blowing up the rocks!

		[FoC] ribdeth 