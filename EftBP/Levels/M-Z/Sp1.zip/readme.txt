Schlabo's Playground
--------------------

Gemacht von: Schlabo
Erstellt am: 26.10.1999
Version: 1.0
Spieler: 2-4
Kartengr��e: Mittel

Beschreibung: Die Spieler starten an den Ecken, jeder hat sein eigenes Rohstofffeld. In der Mitte der Karte ist eine gro�e Insel, umgeben von einem ringf�rmigen Flu�. Auf dieser Insel befindet sich nicht nur ein Vulkan sondern auch eine Insel mit einem Artefakt, im Untergrund befindet sich bereits ein vorgebautes Tunnelsystem. Zwischen den einzelnen Startpositionen gibt es jeweils eine schmale Stelle.

Heruntergeladen von:
EarthUniverse ( http://www.e2150.de/ )

--------------------
Please do not modify or remove this readme-file! Thanks!