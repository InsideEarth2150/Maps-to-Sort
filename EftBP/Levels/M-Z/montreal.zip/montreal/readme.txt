HOW TO INSTALL SKIRMISH MAPS
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
by Mikhail Klassen (Ice Man)

Place both the .lnd and .mis file in the Levels folder in your Earth 2150 directory. Start up the game and they will be in the list!

-Ice Man

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Earth Orbiter - http://earth-orbiter.com/
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~