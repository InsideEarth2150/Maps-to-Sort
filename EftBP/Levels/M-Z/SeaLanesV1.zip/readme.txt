Sea Lanes Version 1

By: Tailis
Icq: 59792443
email: Tailis@canada.com


This map was inspired by that great water map for Total Annihilation, Sea Lanes. I had many amazing water battles on it, and felt that Earth 2150 didn't have a good map for oceanic battle. 

This is a medium sized map with room for 2 players. There's a nice amount of resources, and an islands for each team which contain many resources. There are custom placed textures and many minor details which help create a tropical feel to the map. 

This map has not been tested in multiplayer yet. If there are any balance problems or other flaws, feel free to contact me. 

