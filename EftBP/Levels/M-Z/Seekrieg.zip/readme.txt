-------------------------------Lavaland-------------------------------

Title: 			Seekrieg
Version: 		1.0
Filename:		See.LND
			See.mis
Author:			DerDuke
E-Mail:			Derduke@game-extras.de
Homepage:		www.game-extras.de
Release Date:		31.03.2000


-----Level Information-----
Game: 			Earth 2150 Version 2.0 (German)
Level Name:		Seejrieg
Gr��e: 			mittel
Player:			2
Multiplayer:		yes
Singleplayer:		Skirmish


----Level Construction----
Editor(s) used:		Earth 2150 Editor (German)
Base: 			New Map
Construction Time:	1 Day


----Installation----
Unzip Lavaland.zip in your Earth 2150/Levels directory.


----------------------------------------------------------------------------------------

Level Beschreibung

Eine reine Seekarte auf der die Ucs und die ED mit Ihren Schiffen gegeneinander K�mpfen
Es gibt keine Rohstoffe und auch keine Basen. Bitte nur Voreinstellung w�hlen
WAS AUCH GANZ WICHTIG IST DIESE KARTE IST SEHR HARDWAREINTENSIV EIN PENTIUM III 500
ODER ATHLON 500 SOLLTE ES SCHON SEIN!