Map Name - "(6) Snow Fortresses"
Players - 6
Size - Large
Tileset - Winter
Tunnel Layer - no
Water - Yes
Difficult terrian - much
Resources - medium
water - little
Need for expansion - little

Made by Faceless Clock

---------------------

----------------------
Notes:
A snowy map. Players start on one of six large mountains. The only resources are at the 
player start locations. The Terrian has many hills in it, and most fighting will occur at
close ranges. Some hills can be climbed on top of, so use this to your advantage.
----------------------
Installation
To install the map, put the .Ind and .mis files in the C:\programfiles\SSI\earth2150\levels
directory. You may have to create a levels directory in the earth2150 folder. 
----------------------
Feedback
If you have comments or questions about the map, e-mail me at cmsmith@one.net