Map Name - "(4) Twisted Canyon"
Players - 4
Size - Medium
Tileset - Desert
Tunnel Layer - no
Water - no
Difficult terrian - much
Resources - medium
water - none
Need for expansion - medium

Made by Faceless Clock

---------------------

----------------------
Notes:
Players start in one of four boxed shape areas. The only way to the enemy is through small, 
twisting canyons. There middle is a wide open space with some extra resources.
----------------------
Installation
To install the map, put the .Ind and .mis files in the C:\programfiles\SSI\earth2150\levels
directory. You may have to create a levels directory in the earth2150 folder. 
----------------------
Feedback
If you have comments or questions about the map, e-mail me at cmsmith@one.net