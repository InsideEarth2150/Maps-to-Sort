Hallo,
hier auch mal eine Karte von mir :)
Typ: Gro�, Winter, 4 Spieler

Sie wurde mehrfach getestet und ist mit reichlich Ressourcen versehen.
Die Felder lassen sich mit allen Rassen gut abbauen.

Klassische Aufteilung, 4 Corners.
Relativ viel freie Fl�chen f�r den n�tigen Kampf-Platz.
Die KI hat keine Wegfindungs-Probleme und die Karte eignet sich auch f�r den Skirmish-Modus recht gut.


Und hier eine kleine Story, in guter alter TA-Tradition ;)

An diesem Morgen stimmte auch gar nichts. Das Wetter war, wie eigentlich immer in letzter Zeit, erb�rmlich. Ich hatte den Auftrag eine gottverlassene Gegend zu erkunden und, wenn m�glich, zu sichern. Meine Truppen waren durch die vorangegangenen Ereignisse nicht gerade in bester Laune. Und jetzt auch noch diese undankbare Mission.

Sicher, es war ein rohstoffreicher Landstrich, aber die Gefahr auf feindliche Verb�nde zu treffen war f�rmlich zu sp�ren. Ich hatte vergeblich um eine Pause f�r meine Leute gebeten und nun musste ich sie f�r dieses H�llen-Kommando motivieren.

Mein Stab hat mir eine einigerma�en vollst�ndige Lage f�r diesen Abschnitt vorbereitet.
Es befinden sich mehrere ergiebige Rohstofflager in dieser Gegend. Erste Priorit�t hat die Sicherung meiner Startbasis und die Erkundung der Lage der weiteren Minen.
Die teilweise noch vorhandenen �berreste vergangener, besserer Tage sollen unsere Mission nicht gef�hrden. Allerdings stuft man die Gefahr einer feindlichen Pr�senz bei �ber 90% ein.

Ich kann nicht gerade behaupten, dass sich meine Laune bei dem Ausblick auf riskante Erkundungsfl�ge gebessert hat. Zum Gl�ck kann ich auf ausgezeichnetes Material zur�ckgreifen und meine Leute verstehen inzwischen ihr Handwerk. Diese Mission kann uns endg�ltig zu Helden oder zu Legenden machen.

Wenn ich es mir recht �berlege, m�chte ich das Kapitel mit der Legende noch ein wenig verschieben. Mein Adjudant teilt mir soeben die Marschbereitschaft der Truppen mit. Es geht los...


Viel Spa�....

Sanko
