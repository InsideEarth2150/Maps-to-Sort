Himalaje (313)

Mapa z misji Himalaje kampanii LC w Earth 2150 EFTBP
-----

Instalacja:
Pliki .lnd i .mis skopiuj do katalogu levels w folderze twojego Eartha. je�eli nie masz katalogu levels to go utw�rz.

Ilo�� graczy: 2
Wielko��: �rednia
Zasoby: 324250

-----
Map� skonwertowa�:
Rosic

Mapa pobrana ze strony:
www.wec.z.pl

Pytania prosz� kierowa� na adres:
earthrts@interia.pl