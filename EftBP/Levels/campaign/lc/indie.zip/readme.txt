Indie (342)

Mapa z misji Indie kampanii LC w Earth 2150 EFTBP
-----

Instalacja:
Pliki .lnd i .mis skopiuj do katalogu levels w folderze twojego Eartha. je�eli nie masz katalogu levels to go utw�rz.

Ilo�� graczy: 6
Wielko��: Du�a
Zasoby: 948250

-----
Map� skonwertowa�:
Rosic

Mapa pobrana ze strony:
www.wec.z.pl

Pytania prosz� kierowa� na adres:
earthrts@interia.pl