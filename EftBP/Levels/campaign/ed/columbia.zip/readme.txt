Columbia (264)

Mapa z misji Columbia kampanii ED w Earth 2150 EFTBP
-----

Instalacja:
Pliki .lnd i .mis skopiuj do katalogu levels w folderze twojego Eartha. je�eli nie masz katalogu levels to go utw�rz.

Ilo�� graczy: 5
Wielko��: Du�a
Zasoby: 813000

-----
Map� skonwertowa�:
Rosic

Mapa pobrana ze strony:
www.wec.z.pl

Pytania prosz� kierowa� na adres:
earthrts@interia.pl