Alaska (223)

Mapa z misji Alaska kampanii ED w Earth 2150 EFTBP
-----

Instalacja:
Pliki .lnd i .mis skopiuj do katalogu levels w folderze twojego Eartha. je�eli nie masz katalogu levels to go utw�rz.

Ilo�� graczy: 4
Wielko��: �rednia
Zasoby: 665750

-----
Map� skonwertowa�:
Rosic

Mapa pobrana ze strony:
www.wec.z.pl

Pytania prosz� kierowa� na adres:
earthrts@interia.pl