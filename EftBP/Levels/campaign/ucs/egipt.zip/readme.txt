Egipt (153)

Mapa z misji Egipt kampanii UCS w Earth 2150 EFTBP
-----

Instalacja:
Pliki .lnd i .mis skopiuj do katalogu levels w folderze twojego Eartha. je�eli nie masz katalogu levels to go utw�rz.

Ilo�� graczy: 2
Wielko��: Du�a
Zasoby: 612000

-----
Map� skonwertowa�:
Rosic

Mapa pobrana ze strony:
www.wec.z.pl

Pytania prosz� kierowa� na adres:
earthrts@interia.pl