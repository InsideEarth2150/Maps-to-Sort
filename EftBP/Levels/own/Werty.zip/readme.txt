Werty readme:

-----
Witajcie w readme mojej sz�stej mapy.

Instalacja:
Pliki .lnd i .mis skopiuj do katalogu levels w folderze twojego Eartha. je�eli nie masz katalogu levels to go utw�rz.

Mapa jest skonstruowana pod TMP.
Ilo�� graczy: 4
Wielko��: �rednia
Zasoby: 3124250

Map� t� mo�esz rozpowszechnia� darmowo, dop�ki ten plik jest do niej za��czony.

-----
Welcome in readme of my sixth map.

This map was built for TMP.
Max Players: 4
Size: Medium
Resources: 3124250

Instaloation:
You must copy files .lns and .mis to the "levels" brochure in directory of your Earth. If you don't have a "levels", just create it.

This map you can distribute freely, as long as this file is enclosed.

-----
Rosic
earthrts@interia.pl
www.wec.z.pl