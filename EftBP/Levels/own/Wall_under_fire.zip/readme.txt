Wall Under Fire readme:

-----
Witajcie w readme mojej czwartej mapy.

Instalacja:
Pliki .lnd i .mis skopiuj do katalogu levels w folderze twojego Eartha. je�eli nie masz katalogu levels to go utw�rz.

Mapa jest skonstruowana pod Eartha 2150.
Ilo�� graczy: 4
Wielko��: Ma�a
Zasoby: 1147500

Map� t� mo�esz rozpowszechnia� darmowo, dop�ki ten plik jest do niej za��czony.

-----
Welcome in readme of my fourth map.

This map was built for Earth 2150.
Max Players: 4
Size: Small
Resources: 1147500

Instaloation:
You must copy files .lns and .mis to the "levels" brochure in directory of your Earth. If you don't have a "levels", just create it.

This map you can distribute freely, as long as this file is enclosed.

-----
Rosic
earthrts@interia.pl
www.wec.z.pl