Highway To Hell readme:

-----
Witajcie w readme mojej pi�tej mapy.

Instalacja:
Pliki .lnd i .mis skopiuj do katalogu levels w folderze twojego Eartha. je�eli nie masz katalogu levels to go utw�rz.

Mapa jest skonstruowana pod Eartha 2150.
Ilo�� graczy: 8
Wielko��: Du�a
Zasoby: 3123750

Map� t� mo�esz rozpowszechnia� darmowo, dop�ki ten plik jest do niej za��czony.

-----
Welcome in readme of my 5th map.

This map was built for Earth 2150.
Max Players: 8
Size: Big
Resources: 3123750

Instaloation:
You must copy files .lns and .mis to the "levels" brochure in directory of your Earth. If you don't have a "levels", just create it.

This map you can distribute freely, as long as this file is enclosed.

-----
Rosic
earthrts@interia.pl
www.wec.z.pl