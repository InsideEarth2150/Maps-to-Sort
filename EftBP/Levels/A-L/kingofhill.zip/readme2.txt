Map Name - "(4) King of the Hill"
Players - 4
Size - Medium
Tileset - Snow
Tunnel Layer - no
Difficult Terrian - Medium
Resources - much
Water - little
need for expansion - very much

Made by Faceless Clock

---------------------
Incoming Transmission....

Commander, a platoon operating in the Rocky Mountains has found a new sector. The area is 
bordered by mountains and a river. In the center of the sector is a large mountain that 
contains rich resources. We believe that it may have lost it's top during the nuclear war.
The mountain is surrounded by a river. The only way in or out is 8 bridges located around
the mountain. The mountain slopes are steep and hard to naviagate. Take the mountain and
fortify it. Then use the resources to destroy any and all enemy units in the area. 

End Transmission
----------------------
Notes:
This map is just what the name says. In the middle of the map is a large hill with a huge
amount of resources. Take the hill and destroy your enemys.
----------------------
Installation
To install the map, put the .Ind and .mis files in the C:\programfiles\SSI\earth2150\levels
directory. You may have to create a levels directory in the earth2150 folder. I'm not sure,
i didn't check it out before i made the map.
----------------------
Feedback
If you have comments or questions about the map, e-mail me at cmsmith@one.net