-------------------------------Lavaland-------------------------------

Title: 			Lavaland
Version: 		1.0
Filename:		Lavaland.LND
			Lavaland.mis
Author:			DerDuke
E-Mail:			Derduke@game-extras.de
Homepage:		www.game-extras.de
Release Date:		14.03.2000


-----Level Information-----
Game: 			Earth 2150 Version 1.9.3 beta (German)
Level Name:		Lavaland
Gr��e: 			klein
Player:			2
Multiplayer:		yes
Singleplayer:		Skirmish


----Level Construction----
Editor(s) used:		Earth 2150 Editor (German)
Base: 			New Map
Construction Time:	2 Days


----Installation----
Unzip Lavaland.zip in your Earth 2150/Levels directory.


----------------------------------------------------------------------------------------

Level Beschreibung

Kleine Karte durch die ein Lavafluss flie�t. Es gibt 2 kleine Basen und f�r jede Seite 
ca 100000 Rohstoffe. Spieler 1 ist die UCS und Spieler 2 die ED. Bitte schickt mir eine 
E-Mail an derduke@game-extras.de wann Ihr Fehler endeckt oder verbesserungsvorschl�ge habt!