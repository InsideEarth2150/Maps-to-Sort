**********Black Hills, SD**********
          By: Fluffy2150

Size:      Huge
Type:      Spring
Players:   3

Discription:
	I made this map to resemble the terrain of the Black Hills of South Dakota. It is very rocky and hilly. It is rich in resources for good multiplayer or skirmish games. I also put some artifacts on the map to make it interesting.
Thanks for downloading my map!

Extract this .Zip into:
C:/Program files/SSI/Earth2150/Levels/

