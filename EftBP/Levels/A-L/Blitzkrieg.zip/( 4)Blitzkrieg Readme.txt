Extragro�e Karte mit ca. 1800000 CR f�r 4 Spieler.
Ich wei�, dass die CR etwas happig sind, aber bei dieser Karte stehen die
K�mpfe im Vordergrund. Besonders im Tunnel, der sehr gut ausgebaut ist.
Trotzdem sollte man eine Baufahrzeug/Tunnel Digger mit in den Keller nehmen,
denn die Durchg�nge sind teilweise  noch zu.

Copyright f�r die Map liegt alleine bei mir (K�belkind)

Wer die Map auf seiner Homepage ver�ffentlichen will,
soll mir bitte vorher Bescheid geben. 
E-mail: kuebelkind@gmx.de

Dieses Readme mu� immer der Map beiliegen.

Extra-big map with many CR and a very huge tunnelsystem, which is constructed
for 4 players. This map is designed to battle with many units, so you can win
with tanks, but you can crouch through the tunnel or use ships and aircraft
for support.

If you wanna put this map on your homepage please contact me and ask for permission.
E-mail: kuebelkind@gmx.de

The copyright of the map is mine and this readme gotta be with the map.