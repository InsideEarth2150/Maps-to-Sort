

Front Line V1
By MEFlST0

This map may distributed to everyone and copied by everyone, as long as this readme is included

1)Installation
 Make sure You got a map called   levels   in your earth directory (probably C:\Program Files\SSI\Earth 2150)
 then get the 2 unzipped 'LND' and 'MIS' files in the map   levels    and you can select the map in the earth
 2150 skrimish menu


2)Some explainin
 this is the virst version of my map, it doesn't include recourses you'll have to set a cash flow in the
 skirmish menu to play it properly.
 I'm seriously considering makin a map WITH recourses.
 

3)Quik story
 Because you've already got a rather big base I've found this litle story to explain the lack of already
 researched technoligies.
 The ED and UCS have been in a long batle on 2 sides of a river, witch the ED has recently dammed (as in
 put a dam in front of the river) wich has created a lake, in this lake the LC have artificially enlarged an 
 island.
 Because the Earth's magnetic field is unstabel in her way to the sun, the earth's magnetic field has erased 
 all computer stored data, such as build plans for units, weapons and buildings. therefor these things need to
 be re-researched :)


4)Anyone can review my map, all I ask in return is that you notice me (unless I send YOU the map ofcourse :)
  


 Greetings 
 MEFlST0
 if you have comments you can send them at:
 marc.gubbels@pandora.be
