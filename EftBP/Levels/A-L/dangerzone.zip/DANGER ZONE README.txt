HI ALL!!!

DanGer ZOne map von [ISF]HELLY..:


Die map beinhaltet viele Recourcen und die 10 m�gl. Spieler m�ssen schnell ausbauen und die Nachbar "boxen" einnehmen, um die eigene Basis auszubauen. Dies erzwingt RUSH. Die map ist eigentlich nur f�r LC ausgelegt, da auch auf den f�r fahrzeuge nicht erreichbaren Gebirgskamm einige Geb�ude gebaut werden k�nnen.
(ED oder UCS m�ssen den einheiten Transporter benutzen, um die Baufahrzeuge dorthin zu bef�rdern.

ZUM spielen der map kopieren sie alle daten in das LEVELS verzeichnis ihres moonproject Ordners.

VIEL SPASS !!

[ISF]HELLY