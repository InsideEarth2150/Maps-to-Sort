===============
INSTALLATION
~~~~~~~~~~~~~~~
To install the map, put the .Ind and .mis files in the C:\programfiles\SSI\earth2150\levels
directory. You may have to create a levels directory in the earth2150 folder.
===============
Please Visit Earth Orbiter at http://everything.at/earth2150 for more maps and daily news updates
===============

DESCRIPTION
~~~~~~~~~~~
Comments or questions may be directed to Chip at dsamain1@home.com
Map Name - GLOUCESTER HARBOR
FOR: Earth 2150
Players - 6
Size - Huge
Tileset - Sprinng w/mountains
Tunnel Layer - Yes
Water - Yes
Difficult terrian - Periphery and several interior hilltops
Resources - High
Need for expansion - Player's discretion

Created by Chip

---------------------

----------------------
SITUATION:   Gloucester Harbor*, above 42 degrees 36 minutes North has many inlets and an abundance of decimated infrastructure.
Near the 36 minute line, at the bottom of the map is Tenpound Island.  This land mass is rich in resource deposits. Harbor
Cove and the Inner Harbor area are densely populated with berths and the remnants of the shipping and receiving complexes.
Some areas are suitable for the fabrication of ship building facilities.  The Rocky Neck and South Cove areas contain many of the
ruins, artifacts and resources. Naval patrols, in force, will aid in securing the industrial area and the inland waterway.
Meandering west and then north of the the top of the Western Harbor area is the Blynman Canal and Annisquam River.
This waterway is crossed by old Massachusetts State Route 127 near the mouth of the canal, the B&M Railroad just above
the 37 minutes line(Bascule Bridge), then again to the north by old Massachusetts State Route 128 at Ferry Hill.
To the south of Rt. 128, Wolf Hill gives a commanding view of surrounding terrain and the main river crossings.

ORDER OF BATTLE:  Each faction starts with one vehicle.  Resources will be critical until new resource fields are isolated.
From all of the start points, many of the strategically valuable points lie to the south.
Engineering and bridging assets should accompany forward maneuver elements as the status of the bridges is
questionable.  Heavily cratered, bomb shattered areas may slow progress in certain areas.  Once again, engineering and
 bridging units will prove most valuable.  Possession of high ground near the Annisquam River crossing(s) is key to controlling
the map for the drive into the harbor and industrial area(s).

NOTES: If something is in the way, move it.  Targetable heavy weapons can be a valuable tool.

* Real maps of this area are easily obtainable, which if you're interested, will aid in understanding the boundaries and
reference points named earlier in this readme file. This knowledge, however, is not imperative to effective game play.