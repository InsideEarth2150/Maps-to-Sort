                   Knossus
_________________________________________________

8 Player Tournament style map for 2v2 or 4v4.  
Players 1-4 are on the East side, and 5-8 on the 
West.  No Tunnels.  No artifacts.  Lots of 
resources! Pretty flat, and design slows rushes a
little, but not alot, so be prepared.  Air is 
slowed down a little, and AA Units are offered 
a bit of protection.  Key to game is controlling 
the extra resource patches. This is my attempt at
making a bland map good for multiplayer gaming.  

		[FoC] Ribdeth