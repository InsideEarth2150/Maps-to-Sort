Spiel-Typ:		Kill`Em all
Map Typ:		Mittel (Sommer)
Max Anzahl Spieler:	6
Startcredits:		20.000
Zeitlimit:		Kein Zeitlimit
Start-Einheiten:	nach Vorgabe oder nur Baufahrzeuge
Spieler und Rassen:	2x ED, 2x LC, 2x UCS
Credits enthalten:	1.570.000

Bergreiche Map, die etliche Ressourcenfelder enth�lt. Im Skirmish besonders dann interessant, wenn man gegen alle 5 Gegner spielt. Im MP dadurch interessant, da� die Startpunkte einer Partei (z.B. UCS) nicht nebeneinander liegen, ein Gegner mindestens ist immer dazwischen.

Decion


