ARRGmap von ISF leader Helly:

eine grosse Karte f�r TMP matches


Es befinden sich 2Grosse Ressourcenfelder auf der map, die nur durch Errichten eines Tunnels erreichbar werden. Jeweils rechts oben und links unten.

Es sind sehr viele ressourcen vorhanden und die Karte bietet platz f�r 6 Spieler.

Um diese map Spielen zu k�nnen, m�ssen sie die dateien ARRGmap[ISF].ind sowie ARRGmap[ISF].mis in den unterordner LEVELS ihres Moonproject verzeichnisses kopieren.
Ist der ordner LEVELS nicht vorhanden, m�ssen sie ihn erstellen.