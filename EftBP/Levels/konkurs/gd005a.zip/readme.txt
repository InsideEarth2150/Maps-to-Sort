gd005a

-----

Instalacja:
Pliki .lnd i .mis skopiuj do katalogu levels w folderze twojego Eartha. je�eli nie masz katalogu levels to go utw�rz.

Mapa jest skonstruowana pod Eartha 2150.
Ilo�� graczy: 8
Wielko��: �rednia
Zasoby: 4781250

-----
Autor: GD

Wszelkie pytania prosz� kierowa� pod adres: earthrts@interia.pl
Mapa �ci�gni�ta zosta�a ze strony: www.wec.z.pl

