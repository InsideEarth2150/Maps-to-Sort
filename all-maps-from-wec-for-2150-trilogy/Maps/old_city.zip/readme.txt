=-=-=-=-=-=-=[Old city - ReadMe]=-=-=-=-=-=-=

Wielko��	size			�rednia; medium
Ilo�� graczy	max players		4
Zasoby		Resources		3532500
Typ terenu	Type of ground 		lato; summer
Autor		author			Albert [Aldi]
Adres e-mail	address e-mail		black-cat@w.pl
Data produkcji	date of production	13-08-02 17:00
Stworzone w...	Created in... 		Earth 2150: The Moon Project


Instalacja:
Pliki .lnd i .mis skopiuj do katalogu levels w folderze twojego Eartha. je�eli nie masz katalogu levels to go utw�rz.

Instaloation:
You must copy files .lns and .mis to the "levels" brochure in directory of your Earth. If you don't have a "levels", just create it.

Made in Poland

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=