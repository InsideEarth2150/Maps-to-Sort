Extreme Dorito v. 1
=======================================================
Map for Earth 2150 and The Moon Project
Platforms and ramps.  Some Water. 
Vegetation in places. 

For 4 players.  
Medium Resources. 

=======================================================
This map was created by Chip and play tested by the
Forces of Chaos clan.  You may not display this map
on any website without permission. 

(c) 2002 by Chip