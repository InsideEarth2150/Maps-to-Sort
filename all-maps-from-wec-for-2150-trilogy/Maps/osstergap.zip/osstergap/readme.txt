EARTH ORBITER MAP DOWNLOAD
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
http://everything.at/earth2150
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Map Name - OSSTER GAP
FOR: Earth 2150
Players - 3
Size - Huge
Tileset - Winter
Tunnel Layer - Yes
Water - Yes
Difficult terrian - much
Resources - High
Need for expansion - Player's discretion

Created by Chip

---------------------

----------------------
SITUATION:  In August 2150, UCS forces, in a desperate attempt to dissuade ED forces from further attempts of conquest
on the UCS mainland, landed a massive force on the Finnish coast, ran North, rounded the top of the peninsula, then
drove for the heart of Europe.  Going was easy. Much of the ED war machine was committed in Africa and Southern
Asia, leaving central Europe wide open. When the ED finally brought an effective counterattack to bear, the UCS
drive stalled and rough lines were drawn. Both sides halted to replenish their armies. In recent weeks, LC forces
have entered the area to exploit the weakened state of UCS and ED forces to collect resources.

-At the edge of the Ural Mountains, along the battle etched border between the ED and UCS, is a small break in the
jagged terrain.  Past the Yuryuzon River, to the North, lies the OSSTER GAP.  The area is seldom rememberd by other than locals, though
most have either fled or been exterminated.  ED Warlords have pulled back South of the mountains to re-assemble and
refit their forces in the area.  Cursory probes reveal that the OSSTER GAP is suitable for the passage
of a heavy mounted armored force.  Present at the North end of OSSTER GAP is a sizeable UCS force.
Beyond lies a vast resource field currently being utilized by the UCS.
-The terrain to either side of the pass is irregular and disected.  Minor high level passes may provide alternate routes
through areas with restrictive slopes or unsuitable surfaces.  The Yuryuzon River crosses the area to the South of the mountains.
Several bridges span the river, though their condition is questionable.  As the bridges may not have been maintained in some time,
construction/engineering assets with bridging hardware are adviseable.
-UCS forces have a clear field of fire and ready view of the Northern mouth of OSSTER GAP.  The UCS
base area is planar with excellent visiblity of the forward contingent guardig the pass, the resource fields and refining operations.
Visibility extends to the base of the mountains and the Northern mouth of the pass.  Visibility past the mountains and into the pass
is negligible. Fog and snow may decrease visual range. ED and LC forces have clear visibility to the South and West.  Visual range
is limited to the East and North due to disected and severely sloping terrain.
-According to satellite imgery, the Yuryuzon River islands contain remnants of an ore refining complex.  River erosion has left
freshly exposed land which strongly suggests the presence of abundant resources.

ORDER OF BATTLE:  ED/LC forces are present in small elements at this time. The probability of LC/ED contact is high.  LC forces
will be primarily concerned with mining operations, and will undertake all operations necessary ot eliminate any threat.  ED forces
will be largely be concerned with capturing and holding the pass.  Operations to wipe out the UCS threat to the North is
suggested.  UCS forces are primarily concerned with holding the pass and making sure that nothing unfriendly comes
through or over the mountains.

NOTES:  This map, if you're playing UCS is a nifty defense primer.  If you're any of the other factions, then you will need
to be creative.  The terrain offers a few challenges.  Be prepared for a battle at the border checkpoint that spans the gap.
You will find the UCS base adequately defended at the onset of the game.  Be prepared to undertake operations that exploit different
avenues of approach.  Non-UCS players, be very quick in creating your mobile and defense forces.  I played this one a few times
after I made it and the game play was decent for all sides.  Do your own thing... just keep in mind what you've been told
regarding this map.  Also, be prepared for surprises... good and bad.  First impressions aren't always correct.  Look twice at
everything. Obstacles are intentional. Last thoughts... don't get behind on research... ALWAYS THINK!!!  Have fun. Comments are
 ALWAYS welcome.

----------------------
Installation
To install the map, put the .Ind and .mis files in the C:\programfiles\SSI\earth2150\levels
directory. You may have to create a levels directory in the earth2150 folder.
----------------------
Comments or questions may be directed to Chip at dsamain@home.com
