Name: Water World - Earth2150 Map
Author: Undataka - (daundataka@hotmail.com)
Map size: Large
Max Players: 3
Completion Date: 11/10/00

- Introduction

This is my first map
It is a large summer map. The terrain was initially created by the generator but has been heavily modified. All textures were textured by me.

- Description

Once a bustling city near the Atlantic coast of the North American continent, Rockville was completely destroyed during the onset of the Great War. Recent climatic changes have caused massive flooding and meteorite showers.
The tunnel system consists of a large alien ship as well as the ancient subway system.
Resources are plentiful and I would suggest playing with 20000cr/min anyways



- Install
Extract the file into your earth2150\levels directory. If the folder "Levels" does not exist then create it. Start up the game and it should be there!

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Earth Orbiter - http://everything.at/earth2150
