Autor:		Kurgan
erstellt am:	4.7.2000
Name:		Armstrongs Island

Terrain:	Lava 
Spielerzahl:	8
Gr�sse:		gross
Ressourcen:	ausreichend
Schiffe:	nein
Tunnel:		nein

Simuliert wird eine Mondlandschaft.

Habt Spass damit.
Kurgan

