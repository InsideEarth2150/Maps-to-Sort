EARTH ORBITER MAP DOWNLOAD
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
http://everything.at/earth2150/
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Map Name - D.B. NAS
FOR: Earth 2150
Players - 6
Size - Huge
Tileset - Summer w/mountains
Tunnel Layer - Yes
Water - Yes
Difficult terrian - Periphery, heavily forested areas and several interior hilltops
Resources - High
Need for expansion - Player's discretion

Created by Chip

---------------------

----------------------
SITUATION: D. Brazeale Naval Air Station was once a jewel in the crown of UCS forces.  The installation,
lying in ruins for a decade, has become a hot point of centention between UCS and ED forces.
The ingenuity of the engineers and builders, now long since gone, is evident throughout.
To this day, the runway lights and many of the streetlights on post eerily glow day and night. Much of the
working equipment has resource value. In a pinch, a street lamp, if it's still working, could help you
out as far as generating some capital. In the northwest corner of the map lies a flat open tract of land,
isolated from the others by a river and its delta to the south. UCS forces may be massing in this area.
The northeast corner holds the former admin complex and some gutted barracks. Directly south lies the
airfield.  ED forces have been sighted moving toward a possible staging area on the central river island
just to the west of the airfield.  LC forces are rumored to be in the area, but have not been sighted.
Heavily cratered, bomb shattered areas may slow progress in certain areas.
Resources will be plentiful.  From all of the start points, many of the strategically
valuable points lie to the south. Engineering and bridging assets should accompany forward maneuver
elements as the status of the bridges is questionable.  The tunnel maps for this area have long
since been destroyed.  If you choose to brave the subterranean layer you might come out ahead...
or not...

NOTES: Many gutted checkpoints dot the map.  In many cases, closed gates are blocking key roads.
If something is in the way, move it. Targetable heavy weapons can be a valuable tool.


----------------------
Installation
To install the map, put the .Ind and .mis files in the C:\programfiles\SSI\earth2150\levels
directory. You may have to create a levels directory in the earth2150 folder.
----------------------
Comments or questions may be directed to Chip at dsa9@hotmail.com

