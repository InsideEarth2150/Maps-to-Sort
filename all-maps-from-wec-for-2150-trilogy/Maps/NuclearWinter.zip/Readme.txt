Map: (4)Nuclear Winter
Author: [UEF] Camaris
Kontakt: camaris@cyberlympics.de
Bin �ber jegliche konstruktive Kritik gl�cklich!
Bauzeit: 4 Stunden.
Dank an: Topware f�r das geniale Spiel.

Zur Map:

Spieler: 4
Resourcen: 2.500.000
Gr��e: mittel
Beschreibung:

In der Map werden 4 Hochebenen durch ein kreuzf�rmig verlaufendes Tal getrennt.
Zu jeder Hochebene gibt es 2 gut verteidigbare Aufg�nge.
Pro Ebene ist ein grosses uns ein kleines Mineralienfeld.
Jeweils zwischen den Ebenen direkt bei den Aufg�ngen sind 4 weitere Felder.
2 Grosse Felder sind in der Ruinenstadt in der Mitte der Karte.
Die Ebenen bieten gen�gend Bauplatz, und die Rohstoffe reichen dort f�r eine
gewisse Zeit.
Luftarmeen sind hier ein Vorteil, da es schwer ist die Aufg�nge zu erklimmen.


Greets an alle die mich kennen.
