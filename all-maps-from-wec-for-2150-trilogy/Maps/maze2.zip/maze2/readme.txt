HOW TO INSTALL SKIRMISH MAPS
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
by Mikhail Klassen (Ice Man)

Place both the .lnd and .mis file in the Levels folder in your Earth 2150 directory.  If the Levels folder does not already exist, then create it. Start up the game and they will be in the list!
The main Earth 2150 directory is usually C:\Program Files\SSI\Earth 2150\

-Ice Man

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Earth Orbiter - http://everything.at/earth2150
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~