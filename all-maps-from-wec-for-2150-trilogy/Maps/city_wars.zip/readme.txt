=-=-=-=-=-=-=[City wars ReadMe]=-=-=-=-=-=-=
Dane:
Typ terenu: 	pustynia
Wielko��: 	�rednia
Zasoby: 	1272000
Czas pracy: 	3 godz.

Autor:
Albert J�wik (Aldi)
e-mail: black-cat@w.pl

Plik pobrany ze strony www.wec.z.pl

�ycz� przyjemnej gry.
=-=-=-=-=-=-==-=-=-=-=-=-==-=-=-=-=-=-=

Data: 
Type of ground: desert 
Size : medium
Resources: 1272000 
Time of work : 3 hour 
 
Author: 
Albert J�wik( Aldi) 
E-mail: black-cat@w. pl 
 
File received from pages www.wec.z.pl

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=