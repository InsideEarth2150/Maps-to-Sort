Name: Seagull Coast - Earth2150 Map
Author: Fuel - (mr_bucket@hotmail.com)
URL: http://www.geocities.com/earth2150info/
Map size: Large
Max Players: 5
Completion Date: 6/25/00

- Introduction

Hey, thanks for downloading this map. Seagull Coast is the first map I have ever made for Earth2150.
It is a LARGE WINTER map detailed by me, not the generator. This version of the map is made for 5 players, I don't mind 
if anyone wants to edit it to incorporate more or less. I might change it myself in the future...
It took almost a full day to make this thing, so I hope you enjoy it. This map is ideal for an all night LAN party.
..and Please: DISTRIBUTE FREELY!

- Description

Somewhere near the arctic circle lies Seagull Coast... a map made to satisfy those gamers who like long games. This map has more than enough resourses, and (as the 
name implies) a long coast to the west. The recent climatic changes on earth have caused icebergs to break free of the mainland and drift into the ocean near the south 
making it a hazard to shipping. There are no residents in the area, and the few that existed before the great war are long vanished, leaving a shell of a town on one 
of the islands.  The land is baren and cold, vegitation only exists in the form of snow covered moss and lichen on various parts of the coast. All in all not a hospitable 
place.... there are bridges connecting the major continents so travel shouldn't be a problem... If you find any errors or have suggestions please feel free to email me.

- Install
just extract into your Earth 2150/levels/ directory and you should be good to go. In the game it should appear on your list as ( 5) Seagull Coast. 

ENJOY!
-Fuel