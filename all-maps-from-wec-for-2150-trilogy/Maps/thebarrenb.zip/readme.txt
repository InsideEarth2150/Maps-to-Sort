Map Name - "(4) The Barren Battlefield"
Players - 4
Size - Medium
Tileset - Desert
Tunnel Layer - yes
Water - Yes
Resources - 150000 at start points, 60000 in all others
Made by Faceless Clock

---------------------
Incoming Transmission....

Commander, our scouts have found a area of rich resources in the middle of former Mexico. 
Scouts report of at least 6 resource patchs in the sector. Travel to the sector, 
set up a base, and put the sector under our control. 

Note that the area has a canyon going threw the middle of the sector, from the sw to the ne.
Three bridges can provide transport across. It is vital you take and hold them. It is also
vital that you find and secure the extra resource patchs in the sector. Destroy any enemy 
units and/or bases. 

The sector has bases, dunes, and other land features that can be used for defense of your 
base. Locate and secure them if nessacary.

End Transmission
----------------------
Notes:
This is my first attempt at making a map. The map is made for 2vs2, but it also can 
make for a good one on one or FFA, if you have four players. 
You may find some area that seem flat but you can't build on at the corners of that maps.
These areas aren't very big. They are there because of the way maps in Earth2150 are. The
maps are created with some ground outside of the map so you can add in background features.
----------------------
Installation
To install the map, put the .Ind and .mis files in the C:\programfiles\SSI\earth2150\levels
directory. You may have to create a levels directory in the earth2150 folder. I'm not sure,
i didn't check it out before i made the map.
----------------------
Feedback
If you have comments or questions about the map, e-mail me at cmsmith@one.net