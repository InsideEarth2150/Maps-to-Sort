This is my first attempt at creating an Earth2150 map. It is a small map, for 2 players, as the name implies. I have tried to make the scenery beautiful, as well as functional. There are many bottlenecks and defensive locations, so you might want to develop your airforce... You might also try burrowing toward the enemy... 

I have tested the map in skirmish mode several times, and everything seems to work fine. The AI is usually better when given resources rather than having to mine them...


Just unzip this file to your Earth2150 main folder and then start a skirmish game!

The fine print: As usual, I'm not responsible for anything, and you're not allowed to use this map as a base for modification without my consent first! 

To get that, or report errors, or just to say you enjoy it and want more, write to me at TomMiskey@hotmail.com .