		LOUTRE CREEK
______________________________________________________

This is a 2v2 team map.  Players 1&2 take the south 
side and 3&4 take the north.  There's 1 big bridge
in the middle that everyone must share.  There are also
shallow points where bridges may be built.  1 tunnel
system right down the middle.  The tunnel and shallow
points are important in case the bridge gets blown up,
or if it gets controlled by the enemy.  Team Players
must decide who will get resources in the middle of
their side.  This map does not provide the best game
against the computer.  Computer does not use tunnels,
blow up bridges, or use resources properly.  Resources
should provide a decent length game, but it helps to be
a little conservative.