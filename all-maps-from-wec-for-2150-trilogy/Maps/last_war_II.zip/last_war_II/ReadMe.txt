=-=-=-=-=-=-=-=-=[Last War II - ReadMe]=-=-=-=-=-=-=-=-=

Wielko��	size			�rednia; medium
Ilo�� graczy	max players		8
Zasoby		Resources		3861000
Typ terenu	Type of ground 		wiosna; spring
Autor		author			Albert [Aldi]
Adres e-mail	address e-mail		aldi666@wp.pl
Data produkcji	date of production	03-07-02
Stworzone w...	Created in... 		The Moon Project

Instalacja:
Pliki .lnd i .mis skopiuj do katalogu levels w folderze 
twojego Eartha. je�eli nie masz katalogu levels to go utw�rz.

Instaloation:
You must copy files .lns and .mis to the "levels" brochure
 in directory of your Earth. If you don't have a "levels", 
just create it.

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=