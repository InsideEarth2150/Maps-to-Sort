=-=-=-=-=-=-=[Zone of Death - ReadMe]=-=-=-=-=-=-=

Wielko��	size			�rednia; medium
Ilo�� graczy	max players		8
Zasoby		Resources		114430750
Typ terenu	Type of ground 		Wiosna; spring
Autor		author			Albert [Aldi]
Adres e-mail	address e-mail		black-cat@w.pl
Data produkcji	date of production	12-01-03 15:30
Stworzone w...	Created in... 		Earth 2150: The Moon Project

Instalacja:
Pliki .lnd i .mis skopiuj do katalogu levels w folderze twojego Eartha. je�eli nie masz katalogu levels to go utw�rz.

Instaloation:
You must copy files .lns and .mis to the "levels" brochure in directory of your Earth. If you don't have a "levels", just create it.

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=